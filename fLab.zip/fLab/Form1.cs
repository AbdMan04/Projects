﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fLab
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void saveImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void saveImageToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog sv = new SaveFileDialog();
            sv.Filter = "PNG Image|*.png|JPEG Image|*.jpg|Bitmap Image|*.bmp|GIF Image|*.gif";
            sv.Title = "Save Image ";
            sv.FileName = "newImage";
            if (sv.ShowDialog()==DialogResult.OK) 
            {
                pictureBox1.Image.Save(sv.FileName);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            SaveFileDialog sv = new SaveFileDialog();
        }

        private void aboutYouToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Name: Abd-Alrahman Bilal BaniOmar \nId: 160856");
        }

        private TabPage GetTabPage2()
        {
            return tabPage2;
        }

        private void goPage2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Clear(); textBox3.Clear(); textBox2.Clear(); textBox4.Clear();
            textBox5.Clear();
            button1.Enabled = button2.Enabled = button3.Enabled = false;

            

        }

        private void printPointsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Missing value!", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            double x1, y1, x2, y2;
            bool ok1 = double.TryParse(textBox1.Text.Trim(), out x1);
            bool ok2 = double.TryParse(textBox2.Text.Trim(), out x2);
            bool ok3 = double.TryParse(textBox3.Text.Trim(), out y1);
            bool ok4 = double.TryParse(textBox4.Text.Trim(), out y2);

            if (!(ok1 && ok2 && ok3 && ok4))
            {
                MessageBox.Show("Incorrect Format!", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            textBox5.Text = $"Start Point is: ({x1}, {y1}){Environment.NewLine}End Point is: ({x2}, {y2})\n";
            button1.Enabled = button2.Enabled = button3.Enabled = true;

            
            tabControl1.SelectedTab = tabPage3;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }
        string bol , ita;
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked && checkBox2.Checked)
            {
                bol = "Bold";
                ita = "Italic";
                textBox5.Font = new Font(textBox5.Font, FontStyle.Bold | FontStyle.Italic);
            }
            else if (checkBox1.Checked)
            {
                bol = "Bold";
                ita = "";
                textBox5.Font = new Font(textBox5.Font, FontStyle.Bold);
            }
            else if (checkBox2.Checked)
            {
                ita = "Italic";
                bol = "";
                textBox5.Font = new Font(textBox5.Font, FontStyle.Italic);
            }
            else
            {
                bol = "";
                ita = "";
                textBox5.Font = new Font(textBox5.Font, FontStyle.Regular);
            }
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x1 = double.Parse(textBox1.Text);
            double y1 = double.Parse(textBox3.Text);
            double x2 = double.Parse(textBox2.Text);
            double y2 = double.Parse(textBox4.Text);

            
            double d = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
            textBox5.AppendText($"\nDistance between the two points is: {d:F2}\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double x1 = double.Parse(textBox1.Text);
            double y1 = double.Parse(textBox3.Text);
            double x2 = double.Parse(textBox2.Text);
            double y2 = double.Parse(textBox4.Text);
            double mx = (x1 + x2) / 2.0;
            double my = (y1 + y2) / 2.0;
            textBox5.AppendText(Environment.NewLine + $"Mid point is: ({mx}, {my})");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            double x1 = double.Parse(textBox1.Text);
            double y1 = double.Parse(textBox3.Text);
            double x2 = double.Parse(textBox2.Text);
            double y2 = double.Parse(textBox4.Text);
            double dx = x2 - x1;
            double dy = y2 - y1;

            string slopeText;
            if (dx == 0)
            {
                slopeText = "\nThe line is vertical\n";

                pictureBox2.Image = Properties.Resources.verticallll;
            }
            else if (dy == 0)
            {
                
                slopeText = "\nThe line is horizontal\n";
                pictureBox2.Image = Properties.Resources.horizontal;

            }
            else
            {
                double m = dy / dx;
                slopeText = $"Slope is: {m}\n";
                if (m > 0)
                {
                    slopeText = $"Slope is: {m}\n";
                    slopeText ="Right side of the line is higher than the left side!\n";
                    pictureBox2.Image = Properties.Resources.positive3;
                }
                else
                {
                    slopeText = "Line goes down and right!\n";
                    pictureBox2.Image = Properties.Resources.negative1;
                }
            }


            textBox5.AppendText(Environment.NewLine + slopeText);
                tabControl1.SelectedTab = tabPage3;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked && checkBox2.Checked)
            {
                bol = "Bold";
                ita = "Italic";
                textBox5.Font = new Font(textBox5.Font, FontStyle.Bold | FontStyle.Italic);
            }
            else if (checkBox1.Checked)
            {
                bol = "Bold";
                ita = "";
                textBox5.Font = new Font(textBox5.Font, FontStyle.Bold);
            }
            else if (checkBox2.Checked)
            {
                ita = "Italic";
                bol = "";
                textBox5.Font = new Font(textBox5.Font, FontStyle.Italic);
            }
            else
            {
                bol = "";
                ita = "";
                textBox5.Font = new Font(textBox5.Font, FontStyle.Regular);
            }



        }
    }
}
