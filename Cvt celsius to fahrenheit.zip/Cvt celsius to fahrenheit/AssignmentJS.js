    function tofahrenheit()
	{	
        var celsius=parseFloat(document.getElementById("txtCelsius").value);
        if(isNaN(celsius))
		{
            window.alert("Please enter a valid number for Celsius.");
            return -1;
        }	
        var fahrenheit=32+(celsius*9/5);
        document.getElementById("txtFahrenheit").value=fahrenheit;
    }
    function random()
	{
        var min=5;
        var max=30;
        var randomNum=Math.floor(Math.random()*(max-min+1))+min;
        document.getElementById("randomResult").innerText=randomNum;
	}