﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {InitializeComponent();}
        private void Form1_Load(object sender,EventArgs e)
        {}
        private void saveImageAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sv= new SaveFileDialog();
            sv.Filter ="PNG Image|*.png|JPEG Image|*.jpg|GIF Image|*.gif";
            sv.Title="Save Image ";
            sv.FileName="New Image";
            if(sv.ShowDialog()==DialogResult.OK){pictureBox1.Image.Save(sv.FileName);}
        }

        private void label5_Click(object sender, EventArgs e)
        {}
        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {}
        private void openImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog op=new OpenFileDialog();
            op.Filter="PNG Image|*.png|JPEG Image|*.jpg|GIF Image|*.gif";
            op.Title ="Open Image";

            if(op.ShowDialog()==DialogResult.OK){pictureBox1.Image=Image.FromFile(op.FileName);}
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {Application.Exit();}
        private double CalculateTotalPrice(string type,string option,string flavor,int quantity)
        {
            double beefPrice=0;
             double chickenPrice=0;
            double happyMeal=0;

            if(type=="Beef")
            {
                if(option=="Meal")
                {
                    if(flavor=="Grill Harley")
                        beefPrice=6.75;
                    else if(flavor=="White Mushroom")
                        beefPrice=5.75;
                    else if(flavor=="Maxican")
                        beefPrice=5.25;
                }
                else if(option=="Sandwich")
                {
                    if(flavor=="Grill Harley")
                        beefPrice=6.0;
                    else if(flavor =="White Mushroom")
                        beefPrice=5.0;
                    else if(flavor=="Maxican")
                        beefPrice=4.75;
                }
            }
            else if(type=="Chicken")
            {
                if(option=="Meal")
                {
                    if(flavor=="Grill Harley")
                        chickenPrice=5.75;
                    else if(flavor=="White Mushroom")
                        chickenPrice = 4.75;
                    else if(flavor=="Maxican")
                        chickenPrice=4.25;
                }
                else if(option=="Sandwich")
                {
                    if(flavor=="Grill Harley")
                        chickenPrice=4.75;
                    else if(flavor=="White Mushroom")
                        chickenPrice=4.25;
                    else if(flavor=="Maxican")
                        chickenPrice=4.00;
                }
            }
            else if(type=="Kids")
            {happyMeal=2.5;}
            return quantity * (beefPrice+chickenPrice+happyMeal);
        }
        private bool Validation()
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text)||
                string.IsNullOrWhiteSpace(textBox3.Text)||
                comboBox1.SelectedIndex==-1||listBox1.SelectedIndex==-1
                ||(comboBox2.Enabled&&comboBox2.SelectedIndex==-1))
            {
                MessageBox.Show("Missing Value!");
                return false;
            }
            if(!int.TryParse(textBox3.Text,out int qty))
            {
                MessageBox.Show("Invalid Format!");
                return false;
            }
            if(qty<=0)
            {
                MessageBox.Show("Enter positive quantity!");
                return false;
            }
            return true;
        }
        private void printOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!Validation())
                return;

            int qty=int.Parse(textBox3.Text);
            string name= textBox1.Text.Trim();
            string type= comboBox1.SelectedItem.ToString();
            string flavor= listBox1.SelectedItem.ToString();
            string option =comboBox2.Enabled ? comboBox2.SelectedItem.ToString():"N/A";
            string extras = string.Join(", ",checkedListBox1.CheckedItems.Cast<object>());
            double totalPrice=CalculateTotalPrice(type,option,flavor,qty);

            Order o = new Order();

            o.CustomerName=textBox1.Text.Trim();
            o.DateTime=DateTime.Now;
            o.Type=comboBox1.SelectedItem.ToString();
            o.Flavour=listBox1.SelectedItem.ToString();
            o.Ingredient=string.Join(", ",checkedListBox1.CheckedItems.Cast<object>());
            o.MealSand=comboBox2.Enabled ? comboBox2.SelectedItem.ToString():"Kids";
            o.Quantity=qty;
            o.TotalPrice=totalPrice;

            Program.orderList.Add(o);

            dataGridView1.DataSource=null;
            dataGridView1.DataSource=Program.orderList;

            dataGridView1.Columns["CustomerName"].HeaderText="Customer Name";
            dataGridView1.Columns["DateTime"].HeaderText="Date Time";
            dataGridView1.Columns["MealSand"].HeaderText="Meal/Sandwich";

            MessageBox.Show("You have entered Successfully!");
        }
        private void button1_Click(object sender, EventArgs e)
        {tabControl1.SelectedIndex=1;}
        private void button2_Click(object sender, EventArgs e)
        {tabControl1.SelectedIndex=0;}
        private void clearOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox3.Clear();
            comboBox1.SelectedIndex=-1;
            comboBox2.Enabled=true;
            comboBox2.SelectedIndex=-1;
            listBox1.Items.Clear();
            listBox1.Items.Add("Grill Harley");
            listBox1.Items.Add("White Mushroom");
            listBox1.Items.Add("Maxican");
            listBox1.ClearSelected();
            for (int i=0;i<checkedListBox1.Items.Count;i++)
                checkedListBox1.SetItemChecked(i,false);
        }

        Random ra =new Random();
        private void timer1_Tick(object sender, EventArgs e)
        {
            int n=ra.Next(1,4);
            if(n==1)
            {
                label1.ForeColor=Color.Purple;
                pictureBox1.Image=Properties.Resources.burger;
            }
            else if(n==2)
            {
                label1.ForeColor=Color.Red;
                pictureBox1.Image=Properties.Resources.burger1;
            }
            else
            {
                label1.ForeColor=Color.Green;
                pictureBox1.Image=Properties.Resources.burger2;
            }
        }
        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timer1.Interval=1000;
            timer1.Start();
        }
        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {timer1.Stop();}
        private void tabPage1_Click(object sender, EventArgs e)
        {}
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {MessageBox.Show("Name: ABDULRAHMAN BILAL BANIOMAR\nID: 160856");}
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedItem==null)
                return;

            string type=comboBox1.SelectedItem.ToString();

            if(type=="Kids")
            {
                listBox1.Items.Clear();
                listBox1.Items.Add("Happy Meal");
                listBox1.SelectedIndex=0;
                comboBox2.SelectedIndex=-1;
                comboBox2.Enabled=false;
            }
            else
            {
                comboBox2.Enabled=true;
                listBox1.Items.Clear();
                listBox1.Items.Add("Grill Harley");
                listBox1.Items.Add("White Mushroom");
                listBox1.Items.Add("Maxican");
                listBox1.SelectedIndex=-1;
            }
        }
        private void checkedListBox1_MouseClick(object sender, MouseEventArgs e)
        {}
    }
}

