﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    internal class Order
    {
        string customername,type,flavor,ingredient,mealSand;
        int quantity;
        double totalPrice;
        DateTime dateTime;
        public string CustomerName
        {get=>customername;set=>customername=value;}
        public DateTime DateTime
        {get=>dateTime;set=>dateTime=value;}
        public string Type
        {get=>type;set=>type=value;}
        public string Flavour
        {get=>flavor;set=>flavor=value;}
        public string Ingredient
        {get=>ingredient;set=>ingredient=value;}
        public string MealSand
        {get=>mealSand;set=>mealSand=value;}
        public int Quantity
        {get=>quantity;set=>quantity=value;}
        public double TotalPrice
        {get=>totalPrice;set=>totalPrice=value;}
    }
}
